package com.mygdx.game;

import static com.badlogic.gdx.math.MathUtils.random;

public class GameResources {
    public static final String BACKGROUND_IMG_PATH = "textures/background.png";

    public static final String BLACKOUT_FULL_IMG_PATH = "textures/blackout_full.png";
    public static final String BLACKOUT_TOP_IMG_PATH = "textures/blackout_top.png";
    public static final String BLACKOUT_MIDDLE_IMG_PATH = "textures/blackout_middle.png";

    public static final String BUTTON_SHORT_BG_IMG_PATH = "textures/button_background_short.png";
    public static final String BUTTON_LONG_BG_IMG_PATH = "textures/button_background_long.png";

    public static final String PAUSE_IMG_PATH = "textures/pause.png";
    public static final String LIVE_IMG_PATH = "textures/life.png";

    public static final String BULLET_IMG_PATH = "textures/laser.png";
    public static final String SHIP_IMG_PATH = "textures/ship.png";

     public static String getRandomTexturePath() {
        switch (random.nextInt(4)) {
            case 0: return "textures/sputnik.png";
            case 1: return "textures/meteor.png";
            case 2: return "textures/meteor2.png";
            default: return "textures/trash.png";
        }
    }

    public static final String BACKGROUND_MUSIC_PATH = "sounds/background_music.ogg";
    public static final String DESTROY_SOUND_PATH = "sounds/destroy.mp3";
    public static final String SHOOT_SOUND_PATH = "sounds/shoot.mp3";


    public static final String FONT_PATH = "fonts/Montserrat.ttf";


}
