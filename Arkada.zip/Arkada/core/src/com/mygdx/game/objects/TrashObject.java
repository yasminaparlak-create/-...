package com.mygdx.game.objects;

import static com.badlogic.gdx.math.MathUtils.random;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.GameSession;
import com.mygdx.game.GameSettings;

import java.util.Random;

public class TrashObject extends GameObject  {

    private static final int paddingHorizontal = 30;

    private int livesLeft;

    public TrashObject(int width, int height, String texturePath, World world) {
        super(
                texturePath,
                width / 2 + paddingHorizontal + (new Random()).nextInt((GameSettings.SCREEN_WIDTH - 2 * paddingHorizontal - width)),
                GameSettings.SCREEN_HEIGHT + height / 2,
                width, height,
                GameSettings.TRASH_BIT,
                world
        );

        body.setLinearVelocity(new Vector2(0, -GameSettings.TRASH_VELOCITY));

        float angularVelocityDeg = (random.nextFloat() * 360f - 180f); // [-180, +180]
        body.setAngularVelocity((float) Math.toRadians(angularVelocityDeg));
        livesLeft = 1;
    }

    public boolean isAlive() {
        return livesLeft > 0;
    }

    public boolean isInFrame() {
        return getY() + height / 2 > 0;
    }

    @Override
    public void hit() {
        livesLeft -= 1;
        GameSession.score = GameSession.score + 50;

    }

    @Override
    public void draw(SpriteBatch batch) {
        TextureRegion region = new TextureRegion(texture);
        float rotationDeg = (float) Math.toDegrees(body.getAngle());
        batch.draw(
                region,
                getX() - width / 2f,
                getY() - height / 2f,
                width / 2f, height / 2f,
                width, height,
                1f, 1f,
                rotationDeg

        );
    }

}
