package com.mygdx.game;

public enum GameState {
    PLAYING,
    PAUSED,
    ENDED
}
